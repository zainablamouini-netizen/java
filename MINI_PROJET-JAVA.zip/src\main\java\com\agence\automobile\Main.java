package com.agence.automobile;

import com.agence.automobile.service.ConsoleApp;

public class Main {
    public static void main(String[] args) {
        new ConsoleApp().run();
    }
}
