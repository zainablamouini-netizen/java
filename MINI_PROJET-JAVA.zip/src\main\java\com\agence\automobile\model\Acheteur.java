package com.agence.automobile.model;

public class Acheteur extends Personne {
    public Acheteur(int id, String nom, String telephone) {
        super(id, nom, telephone);
    }
}
