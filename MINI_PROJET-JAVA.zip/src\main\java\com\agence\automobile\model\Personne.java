package com.agence.automobile.model;

public abstract class Personne {
    private final int id;
    private String nom;
    private String telephone;

    protected Personne(int id, String nom, String telephone) {
        this.id = id;
        this.nom = nom;
        this.telephone = telephone;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public String toString() {
        return String.format("[%d] %s - %s", id, nom, telephone);
    }
}
