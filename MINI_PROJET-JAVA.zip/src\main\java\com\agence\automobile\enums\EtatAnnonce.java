package com.agence.automobile.enums;

public enum EtatAnnonce {
    ACTIVE,
    DESACTIVE,
    VENDUE
}
