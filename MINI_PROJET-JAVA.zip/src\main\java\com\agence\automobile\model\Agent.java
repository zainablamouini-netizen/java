package com.agence.automobile.model;

public class Agent extends Personne {
    public Agent(int id, String nom, String telephone) {
        super(id, nom, telephone);
    }
}
