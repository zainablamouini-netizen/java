package com.agence.automobile.enums;

public enum EtatTransaction {
    EN_COURS,
    FINALISEE,
    ANNULEE
}
