package com.agence.automobile.enums;

public enum EtatDemande {
    NOUVELLE,
    EN_COURS,
    TRAITE,
    ANNULEE
}
