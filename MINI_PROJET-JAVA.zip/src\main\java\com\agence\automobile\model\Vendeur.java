package com.agence.automobile.model;

public class Vendeur extends Personne {
    public Vendeur(int id, String nom, String telephone) {
        super(id, nom, telephone);
    }
}
